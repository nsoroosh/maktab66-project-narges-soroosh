// import axios from 'axios'
// import { useState , useEffect } from 'react';
//  function Getcategories() {
//   const [data, setdata] = useState([])
    
//   useEffect(() => {
//     axios.get('http://localhost:3002/subcategory')
//     .then(function (response) {
//       setdata(response.data)
//     })
//     .catch(function (error) {
//       console.log(error);
//     });
  
    
//   }, [])
//   const arr = []
//   return (
//     // <div>
//     //   {data.map(function(d,ind){
//     //      (arr.push(d.name))
//     //      console.log(arr)
//     //      return arr 
//     //   })}
//     // </div>

//   )
//    }
// export default Getcategories   

  
  
  
   
// // render(){
// //   const data = [{},{}]
// //   return (
// //     <div>
// //       {data.map(function(d,ind){
// //         return (<li key={ind}>{d.name}</li>)
// //       })}
// //     </div>
// //   )
// // }