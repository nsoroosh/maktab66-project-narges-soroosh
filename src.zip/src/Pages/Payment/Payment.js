import { Button, Typography } from "@mui/material";
import {api} from "../../Utils/axios";
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import Productpagelyout from "../../Lyouts/ProductPage/Productpagelyout";

function Payment() {
  
}
export default Productpagelyout(Payment);
