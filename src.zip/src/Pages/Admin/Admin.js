import React from 'react'
import Adminpagelyout from '../../Lyouts/AdminPage/Adminpagelaout'

 function Admin() {
  return (
    <div>Admin</div>
  )
}
export default Adminpagelyout(Admin)