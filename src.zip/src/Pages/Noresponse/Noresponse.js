import React from 'react'

export default function Noresponse() {
  return (
    <div>صفحه ی مورد نظر یافت نشد</div>
  )
}
